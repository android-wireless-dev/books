package com.androidbook.simplelivefolder;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;

public class SimpleLiveFolderMenuActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public void onResetData(View view) {
        deleteAllFieldnotes();
        addFieldnote(
            "The Zebra",
            "I was surprised when the zebras started making noise. I'm used to quiet horses, but zebras make a sort of donkey-like noise, and they buck and such as well. \nMore: http://j.mp/afz0Yn");
        addFieldnote(
            "The Baboon",
            "Baboons are found in surprisingly varied habitats and are extremely adaptable. All they need is a water source and a safe sleeping place, such as a tall tree or a cliff face. \nMore: http://j.mp/cZycRs");
        addFieldnote(
            "The Leopard",
            "The leopard is the most elusive of the Big Five, those being the most dangerous animals to hunt in Africa. The Big Five are: the lion, elephant, buffalo, leopard and rhinoceros. \nMore: http://j.mp/ap221U");
        addFieldnote(
            "The Wildebeest",
            "Both males and female wildebeests have curving horns. You'll often see them grazing along with zebras. \nMore: http://j.mp/bpKwff");
        addFieldnote(
            "Cape Buffalo",
            "Both male and female buffaloes have heavy, ridged horns. The horns are formidable weapons against predators and for jostling for space within the herd; males also use the horns in fights for dominance. \nMore: http://j.mp/9qlBTe");
        addFieldnote(
            "The Spotted Hyena",
            "Hyenas have some of the strongest jaws in the animal kingdom. With their powerful teeth and jaws and efficient digestion, the spotted hyena can utilize virtually everything on a carcass except the rumen contents and horns. The parts they cannot eat are regurgitated. Even desiccated carcasses yield protein and minerals during lean times. Because they eat bones, the hyena leaves behind white droppings.\nMore: http://j.mp/ajm2aY");
        addFieldnote(
            "The Duiker",
            "Duikers are small antelopes that inhabit forest or dense bushland.\nMore: http://j.mp/bkK1w6");
        addFieldnote(
            "The Impala",
            "One of the first animals you're likely to see on a game drive is a herd of impala. My friend Monika calls them the rats of the desert, the most common type of African antelope you're likely to see.\nMore: http://j.mp/9Jslga");
        addFieldnote(
            "The Waterbuck",
            "It's easy to identify a waterbuck from behind - it's got a big white ring or target, on its backside.\nMore: http://j.mp/dq7v44");
    }

    private void deleteAllFieldnotes() {
        getContentResolver().delete(SimpleFieldnotesContentProvider.CONTENT_URI,
            null, null);
    }

    private void addFieldnote(String fieldnote, String body) {
        ContentValues values = new ContentValues();
        values.put(SimpleFieldnotesContentProvider.FIELDNOTES_TITLE, fieldnote);
        values.put(SimpleFieldnotesContentProvider.FIELDNOTES_BODY, body);
        getContentResolver().insert(SimpleFieldnotesContentProvider.CONTENT_URI,
            values);
    }
}